cd "D:\Dropbox\Religious riots and electoral politics in India\Replication\"
use "dataset_robustness.dta", clear

xtreg ebjpvs L.fes  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtreg ebjpvs L2.fes  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtreg ebjpvs L3.fes  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

xtreg ebjpvs L.riotnear200 L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtreg ebjpvs L2.riotnear200  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtreg ebjpvs L3.riotnear200  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

import delimited "lagcoeffs.csv", clear 

serrbar coeff1 se1 lags, scale (1.96) xtitle("Years before the election") ytitle("Coefficient estimate") title("Structural regression") yline(0) xlabel(#3, valuelabel) 
graph export "lagstructural.pdf", as(pdf) replace

serrbar coeff2 se2 lags, scale (1.96) xtitle("Years before the election") ytitle("Coefficient estimate") title("Reduced form regression") yline(0) xlabel(#3, valuelabel)
graph export "lagreduced.pdf", as(pdf) replace

