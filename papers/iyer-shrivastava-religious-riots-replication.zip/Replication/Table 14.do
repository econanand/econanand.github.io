cd "D:\Dropbox\Religious riots and electoral politics in India\Replication\"
use "dataset_robustness.dta", clear

xtreg ebjpss L.riotnear200  L.bjprule muslim urb lit ele tap time tsq , fe cl(dist)
xtivreg2 ebjpss (L.riotnear200= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

set more off
xtset dist year
gen lfes=L.fes
gen lbjp=L.bjprule
local i=1
capture drop fesav
capture drop bjpruleav
gen fesav=. 
gen bjpruleav=.
while `i'<=339 {
	local sumfes=0
	local sumbjprule=0
	local n=0
	local t=1
	while `t'<=25 {
		local ind=((`i'-1)*25)+`t'
		local fess=lfes[`ind']
		local bjp=lbjp[`ind']
		if ebjpvs[`ind']!=. {	
			local sumfes= `sumfes'+`fess'
			local sumbjprule= `sumbjprule'+`bjp'
			local ++n
			}
		local ++t
		}
	if `n'!=0 {
		local avefes=`sumfes'/`n'
		local avebjp=`sumbjprule'/`n'
		}
		else {
		local avefes=.
		local avebjp=.
	}
	local t=1
	while `t'<=25 {
		local ind=((`i'-1)*25)+`t'
		quietly replace fesav=`avefes' in `ind'
		quietly replace bjpruleav=`avebjp' in `ind'
		local ++t
		}
	local ++i
	}
	*

capture drop fiveyear
gen fiveyear=0
replace fiveyear=1 if year>=1981 & year<=1985
replace fiveyear=2 if year>=1986 & year<=1990
replace fiveyear=3 if year>=1991 & year<=1995
replace fiveyear=4 if year>=1996

reg L.riotnear200 L.fes L.bjprule fesav bjpruleav time tsq i.fiveyear if ebjpvs!=. & year>1980
capture drop residfe
predict residfe, resid

xtgee ebjpss L.riotnear200 L.bjprule residfe fesav bjpruleav i.fiveyear time tsq if year>1980, family(binomial) link(probit) vce(r)
margins, dydx(L.riotnear200)
glm ebjpss L.riotnear200 L.bjprule residfe fesav bjpruleav i.fiveyear time tsq if year>1980, family(binomial) link(probit) vce(cl dist)	
margins, dydx(L.riotnear200)
