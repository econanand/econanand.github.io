cd "D:\Dropbox\Religious riots and electoral politics in India\Replication\"
use "monthly.dta", clear
xtset dist monthindex

*Figure 3
gen lnriotm=L12.nriotm
gen lfesm=L12.fesm
graph bar (sum) elec (sum) lfesm (sum) lnriotm if year>1980, over(month) bar(1, fcolor(black) lcolor(black)) bar(2, fcolor(black) fintensity(inten50) lcolor(black) lwidth(medium)) bar(3, fcolor(white) lcolor(black) lwidth(medium)) legend(order(1 "Observations with elections" 2 "Observations with Festival=1" 3 "Number of riots"))
graph export "monthly.pdf", as(pdf) replace


*creating quarterly data 
gen quarter=0
replace quarter=1 if month==1|month==2|month==3
replace quarter=2 if month==4|month==5|month==6
replace quarter=3 if month==7|month==8|month==9
replace quarter=4 if month==10|month==11|month==12

gen quarterindex=((year-1977)*4)+quarter

gen distquartin=((dist-1)*100)+quarterindex

bys distquartin: egen ebjpvsq=max(ebjpvs)

xtset dist monthindex
gen lriotnear200q=L2.riotnear200q
gen lfesq=0
replace lfesq=1 if L2.fesm==1|L3.fesm==1|L4.fesm==1
keep if month==1|month==4|month==7|month==10

xtset dist quarterind
gen tq=quarterind
gen tqsq=tq*tq

*Table 17
xi: xtivreg2 ebjpvsq (lriotnear200q=lfesq) L4.bjprule muslim urb lit ele tap tq tqsq i.quarter, fe cl(dist)
xi: xtivreg2 ebjpvsq (L.lriotnear200q=L.lfesq) L4.bjprule muslim urb lit ele tap tq tqsq i.quarter, fe cl(dist)
xi: xtivreg2 ebjpvsq (L2.lriotnear200q=L2.lfesq) L4.bjprule muslim urb lit ele tap tq tqsq i.quarter, fe cl(dist)
xi: xtivreg2 ebjpvsq (L3.lriotnear200q=L3.lfesq) L4.bjprule muslim urb lit ele tap tq tqsq i.quarter, fe cl(dist)

