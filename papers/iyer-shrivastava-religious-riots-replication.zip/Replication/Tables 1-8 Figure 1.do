cd "D:\Dropbox\Religious riots and electoral politics in India\Replication\"
use "dataset_main.dta", clear

*Table 1
tab nriot if riot==1 & nriot==1
tab nriot if riot==1 & nriot>1 & nriot<=5
tab nriot if riot==1 & nriot>5 
tab dur if riot==1 & dur==1
tab dur if riot==1 & dur>1 & dur<=5
tab dur if riot==1 & dur>5 

*Figure 1
graph bar (sum) nriot, over(year) ytitle(Number of riots)

*Table 2
su ebjpvs
su ebjpss
su riot if f.ebjpvs!=.
su bjprule if ebjpvs!=.
su muslim if ebjpvs!=.
su urb if ebjpvs!=.
su lit if ebjpvs!=.
su tap if ebjpvs!=.
su ele if ebjpvs!=.
su fes if f.ebjpvs!=.


*Table 3
xtivreg2 ebjpvs (L.riotnear100= L.fes) L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
estat ic
xtivreg2 ebjpvs (L.riotnear150= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
estat ic
xtivreg2 ebjpvs (L.riotnear200= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
estat ic
xtivreg2 ebjpvs (L.riotnear250= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
estat ic
xtivreg2 ebjpvs (L.riotnear300= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
estat ic

*Table 4
xtreg ebjpvs L.riotnear200 time tsq, fe cl(dist)
xtreg ebjpvs L.riotnear200 L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

xtreg ebjpvs L.fes time tsq, fe cl(dist)
xtreg ebjpvs L.fes L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

xtivreg2 ebjpvs (L.riotnear200=L.fes)  time tsq, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

*Table 5
xtivreg2 ebjpvs (L.riotnear200= L.fes)  time tsq, fe cl(dist) first
xtivreg2 ebjpvs (L.riotnear200= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist) first

xtivreg2 ebjpvs (L.riot= L.fes)  time tsq, fe cl(dist) first
xtivreg2 ebjpvs (L.riot= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist) first

*Table 6
capture drop region
gen region=0
replace region=1 if stnum==5|stnum==6|stnum==12
replace region=2 if stnum==11|stnum==16|stnum==2
replace region=3 if stnum==4|stnum==9
replace region=4 if stnum==1|stnum==7|stnum==8|stnum==14
*0=Central, 1=North, 2=East, 3=West, 4=South
capture drop region1-region4
capture drop region1t-region4t
xi i.region
rename _Iregion_1 region1
rename _Iregion_2 region2
rename _Iregion_3 region3
rename _Iregion_4 region4
gen region1t=region1*time
gen region2t=region2*time
gen region3t=region3*time
gen region4t=region4*time

xi: xtivreg2 ebjpvs (L.riotnear200=L.fes) L.bjprule i.year muslim urb lit ele tap, fe cl(dist)
xi: xtivreg2 ebjpvs (L.riotnear200=L.fes) L.bjprule region1t-region4t muslim urb lit ele tap time tsq, fe cl(dist)

xi: xtivreg2 ebjpvs (L.riotall200=L.fesnormdist200) L.bjprule i.year muslim urb lit ele tap, fe cl(dist)
xi: xtivreg2 ebjpvs (L.riotall200=L.fesnormdist200) L.bjprule region1t-region4t muslim urb lit ele tap time tsq, fe cl(dist)
xi: xtivreg2 ebjpvs (L.riotall200=L.fesnormdist200) L.bjprule region1t-region4t i.year muslim urb lit ele tap time tsq, fe cl(dist)

*Table 7
gen votingage=.
replace votingage=above21 if year<=1988
replace votingage=above18 if year>1988
gen agechange=0
replace agechange=1 if year>1988

gen regrate=.
replace regrate=electors/votingage if ebjpvs!=. & votingage!=. 
gen turnout=.
replace turnout=votes/electors if ebjpvs!=. 

xtivreg2 turnout (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtivreg2 regrate (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtivreg2 votingage (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)
xtivreg2 electors (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)
xtivreg2 votes (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)

*Table 8

bys dist: egen meanmus=mean(muslim)
su meanmus if year>1980, det
capture drop mushigh
gen mushigh=.
replace mushigh=0 if meanmus<8.95
replace mushigh=1 if meanmus>=8.95


xtivreg2 regrate (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if year>1980 & mushigh==1, fe cl(dist)
xtivreg2 regrate (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if year>1980 & mushigh==0, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if year>1980 & mushigh==1, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if year>1980 & mushigh==0, fe cl(dist)

