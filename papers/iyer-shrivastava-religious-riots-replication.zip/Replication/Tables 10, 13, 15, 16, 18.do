cd "D:\Dropbox\Religious riots and electoral politics in India\Replication\"
use "dataset_robustness.dta", clear

*Table 10
xtreg ebjpvs riot200last12m L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtivreg2 ebjpvs (riot200last12m= L.fes) L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

*Table 13
xtivreg2 ebjpvs (L.dead200= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtivreg2 ebjpvs (L.cas200= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

*Table 15
xtreg ebjpvs L.riotnear200 L.bjprule muslim urb lit ele tap time tsq if jk==0 & pu==0, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if jk==0 & pu==0, fe cl(dist)

xtreg ebjpvs L.riotnear200 L.bjprule muslim urb lit ele tap time tsq if year!=1993 & year!=1994, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if year!=1993 & year!=1994, fe cl(dist)

xtreg ebjpvs L.riotnear200 L.bjprule muslim urb lit ele tap time tsq if jk==0 & pu==0 & year!=1993 & year!=1994, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if jk==0 & pu==0 & year!=1993 & year!=1994, fe cl(dist)

xtreg ebjpvs L.riotnear200 L.bjprule muslim urb lit ele tap time tsq if year!=1987 & year!=1991, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200=L.fes) L.bjprule muslim urb lit ele tap time tsq if year!=1987 & year!=1991, fe cl(dist)

*Table 16
xtreg ebjpvs L.riotnear200 L.bjpvs  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200= L.fes) L.bjpvs  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

*Table 18

xtivreg2 ebjpvs (L.riotnear200= L.fes)  L.bjprule muslim1980 urb1980 lit1980 ele1980 tap1980 time tsq, fe cl(dist)

capture drop region
gen region=0
replace region=1 if stnum==5|stnum==6|stnum==12
replace region=2 if stnum==11|stnum==16|stnum==2
replace region=3 if stnum==4|stnum==9
replace region=4 if stnum==1|stnum==7|stnum==8|stnum==14
*0=Central, 1=North, 2=East, 3=West, 4=South
capture drop region1-region4
capture drop region1t-region4t
xi i.region
rename _Iregion_1 region1
rename _Iregion_2 region2
rename _Iregion_3 region3
rename _Iregion_4 region4
gen region1t=region1*time
gen region2t=region2*time
gen region3t=region3*time
gen region4t=region4*time

xi: xtivreg2 ebjpvs (L.riotall200=L.fesnormdist200) L.bjprule region1t-region4t i.year muslim1980 urb1980 lit1980 ele1980 tap1980 time tsq, fe cl(dist)

capture drop riotlit
capture drop feslit
gen riotlit=L.riotnear200*lit1980
gen feslit=L.fes*lit1980

xtivreg2 ebjpvs (L.riotnear200 riotlit= feslit L.fes)  L.bjprule muslim1980 urb1980 lit1980 ele1980 tap1980 time tsq, fe cl(dist)
