cd "D:\Dropbox\Religious riots and electoral politics in India\Replication\"
use "dataset_robustness.dta", clear

*Table 11
gen fes1=0
replace fes1=1 if dushehra==1|diwali==1|ramnavami==1|janmashtami==1|shivratri==1

gen fes2=0
replace fes2=1 if ap==1&(ramnavami==1|ashtami==1|navami==1)
replace fes2=1 if as==1&(janmashtami==1|ashtami==1|navami==1)
replace fes2=1 if bh==1&(holi==1|ramnavami==1|navami==1)
replace fes2=1 if gu==1&(holi==1|ramnavami==1|navami==1)
replace fes2=1 if ha==1&(holi==1|shivratri==1|janmashtami==1)
replace fes2=1 if jk==1&(shivratri==1|janmashtami==1|ramnavami==1)
replace fes2=1 if ka==1&(shivratri==1|ganesh==1|navami==1)
replace fes2=1 if ke==1&(shivratri==1|janmashtami==1|navami==1)
replace fes2=1 if mh==1&(navami==1|ramnavami==1|ganesh==1)
replace fes2=1 if mp==1&(holi==1|ramnavami==1|janmashtami==1)
replace fes2=1 if or==1&(holi==1|ashtami==1|navami==1)
replace fes2=1 if pu==1&(holi==1|ramnavami==1|janmashtami==1)
replace fes2=1 if ra==1&(holi==1|ramnavami==1|janmashtami==1)
replace fes2=1 if tn==1&(janmashtami==1|ganesh==1|navami==1)
replace fes2=1 if up==1&(navami==1|ramnavami==1|janmashtami==1)
replace fes2=1 if wb==1&(holi==1|ashtami==1|navami==1)

xtivreg2 ebjpvs (L.riotnear200=L.fes1) L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200=L.fes2) L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

*Table 12


capture drop fessun
gen fessun=0
replace fessun=1 if ap==1&(ramnsun==1|ashtsun==1|navasun==1|dushsun==1|diwasun==1)
replace fessun=1 if as==1&(janasun==1|ashtsun==1|navasun==1|dushsun==1|diwasun==1)
replace fessun=1 if bh==1&(holisun==1|ramnsun==1|navasun==1|dushsun==1|diwasun==1)
replace fessun=1 if gu==1&(holisun==1|ramnsun==1|navasun==1|dushsun==1|diwasun==1)
replace fessun=1 if ha==1&(holisun==1|shivsun==1|janasun==1|dushsun==1|diwasun==1)
replace fessun=1 if jk==1&(shivsun==1|janasun==1|ramnsun==1|dushsun==1|diwasun==1)
replace fessun=1 if ka==1&(shivsun==1|ganesun==1|navasun==1|dushsun==1|diwasun==1)
replace fessun=1 if ke==1&(shivsun==1|janasun==1|navasun==1|dushsun==1|diwasun==1)
replace fessun=1 if mh==1&(navasun==1|ramnsun==1|ganesun==1|dushsun==1|diwasun==1)
replace fessun=1 if mp==1&(holisun==1|ramnsun==1|janasun==1|dushsun==1|diwasun==1)
replace fessun=1 if or==1&(holisun==1|ashtsun==1|navasun==1|dushsun==1|diwasun==1)
replace fessun=1 if pu==1&(holisun==1|ramnsun==1|janasun==1|dushsun==1|diwasun==1)
replace fessun=1 if ra==1&(holisun==1|ramnsun==1|janasun==1|dushsun==1|diwasun==1)
replace fessun=1 if tn==1&(janasun==1|ganesun==1|navasun==1|dushsun==1|diwasun==1)
replace fessun=1 if up==1&(navasun==1|ramnsun==1|janasun==1|dushsun==1|diwasun==1)
replace fessun=1 if wb==1&(holisun==1|ashtsun==1|navasun==1|dushsun==1|diwasun==1)

capture drop fesmon
gen fesmon=0
replace fesmon=1 if ap==1&(ramnmon==1|ashtmon==1|navamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if as==1&(janamon==1|ashtmon==1|navamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if bh==1&(holimon==1|ramnmon==1|navamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if gu==1&(holimon==1|ramnmon==1|navamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if ha==1&(holimon==1|shivmon==1|janamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if jk==1&(shivmon==1|janamon==1|ramnmon==1|dushmon==1|diwamon==1)
replace fesmon=1 if ka==1&(shivmon==1|ganemon==1|navamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if ke==1&(shivmon==1|janamon==1|navamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if mh==1&(navamon==1|ramnmon==1|ganemon==1|dushmon==1|diwamon==1)
replace fesmon=1 if mp==1&(holimon==1|ramnmon==1|janamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if or==1&(holimon==1|ashtmon==1|navamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if pu==1&(holimon==1|ramnmon==1|janamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if ra==1&(holimon==1|ramnmon==1|janamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if tn==1&(janamon==1|ganemon==1|navamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if up==1&(navamon==1|ramnmon==1|janamon==1|dushmon==1|diwamon==1)
replace fesmon=1 if wb==1&(holimon==1|ashtmon==1|navamon==1|dushmon==1|diwamon==1)

capture drop festue
gen festue=0
replace festue=1 if ap==1&(ramntue==1|ashttue==1|navatue==1|dushtue==1|diwatue==1)
replace festue=1 if as==1&(janatue==1|ashttue==1|navatue==1|dushtue==1|diwatue==1)
replace festue=1 if bh==1&(holitue==1|ramntue==1|navatue==1|dushtue==1|diwatue==1)
replace festue=1 if gu==1&(holitue==1|ramntue==1|navatue==1|dushtue==1|diwatue==1)
replace festue=1 if ha==1&(holitue==1|shivtue==1|janatue==1|dushtue==1|diwatue==1)
replace festue=1 if jk==1&(shivtue==1|janatue==1|ramntue==1|dushtue==1|diwatue==1)
replace festue=1 if ka==1&(shivtue==1|ganetue==1|navatue==1|dushtue==1|diwatue==1)
replace festue=1 if ke==1&(shivtue==1|janatue==1|navatue==1|dushtue==1|diwatue==1)
replace festue=1 if mh==1&(navatue==1|ramntue==1|ganetue==1|dushtue==1|diwatue==1)
replace festue=1 if mp==1&(holitue==1|ramntue==1|janatue==1|dushtue==1|diwatue==1)
replace festue=1 if or==1&(holitue==1|ashttue==1|navatue==1|dushtue==1|diwatue==1)
replace festue=1 if pu==1&(holitue==1|ramntue==1|janatue==1|dushtue==1|diwatue==1)
replace festue=1 if ra==1&(holitue==1|ramntue==1|janatue==1|dushtue==1|diwatue==1)
replace festue=1 if tn==1&(janatue==1|ganetue==1|navatue==1|dushtue==1|diwatue==1)
replace festue=1 if up==1&(navatue==1|ramntue==1|janatue==1|dushtue==1|diwatue==1)
replace festue=1 if wb==1&(holitue==1|ashttue==1|navatue==1|dushtue==1|diwatue==1)

capture drop feswed
gen feswed=0
replace feswed=1 if ap==1&(ramnwed==1|ashtwed==1|navawed==1|dushwed==1|diwawed==1)
replace feswed=1 if as==1&(janawed==1|ashtwed==1|navawed==1|dushwed==1|diwawed==1)
replace feswed=1 if bh==1&(holiwed==1|ramnwed==1|navawed==1|dushwed==1|diwawed==1)
replace feswed=1 if gu==1&(holiwed==1|ramnwed==1|navawed==1|dushwed==1|diwawed==1)
replace feswed=1 if ha==1&(holiwed==1|shivwed==1|janawed==1|dushwed==1|diwawed==1)
replace feswed=1 if jk==1&(shivwed==1|janawed==1|ramnwed==1|dushwed==1|diwawed==1)
replace feswed=1 if ka==1&(shivwed==1|ganewed==1|navawed==1|dushwed==1|diwawed==1)
replace feswed=1 if ke==1&(shivwed==1|janawed==1|navawed==1|dushwed==1|diwawed==1)
replace feswed=1 if mh==1&(navawed==1|ramnwed==1|ganewed==1|dushwed==1|diwawed==1)
replace feswed=1 if mp==1&(holiwed==1|ramnwed==1|janawed==1|dushwed==1|diwawed==1)
replace feswed=1 if or==1&(holiwed==1|ashtwed==1|navawed==1|dushwed==1|diwawed==1)
replace feswed=1 if pu==1&(holiwed==1|ramnwed==1|janawed==1|dushwed==1|diwawed==1)
replace feswed=1 if ra==1&(holiwed==1|ramnwed==1|janawed==1|dushwed==1|diwawed==1)
replace feswed=1 if tn==1&(janawed==1|ganewed==1|navawed==1|dushwed==1|diwawed==1)
replace feswed=1 if up==1&(navawed==1|ramnwed==1|janawed==1|dushwed==1|diwawed==1)
replace feswed=1 if wb==1&(holiwed==1|ashtwed==1|navawed==1|dushwed==1|diwawed==1)

capture drop festhu
gen festhu=0
replace festhu=1 if ap==1&(ramnthu==1|ashtthu==1|navathu==1|dushthu==1|diwathu==1)
replace festhu=1 if as==1&(janathu==1|ashtthu==1|navathu==1|dushthu==1|diwathu==1)
replace festhu=1 if bh==1&(holithu==1|ramnthu==1|navathu==1|dushthu==1|diwathu==1)
replace festhu=1 if gu==1&(holithu==1|ramnthu==1|navathu==1|dushthu==1|diwathu==1)
replace festhu=1 if ha==1&(holithu==1|shivthu==1|janathu==1|dushthu==1|diwathu==1)
replace festhu=1 if jk==1&(shivthu==1|janathu==1|ramnthu==1|dushthu==1|diwathu==1)
replace festhu=1 if ka==1&(shivthu==1|ganethu==1|navathu==1|dushthu==1|diwathu==1)
replace festhu=1 if ke==1&(shivthu==1|janathu==1|navathu==1|dushthu==1|diwathu==1)
replace festhu=1 if mh==1&(navathu==1|ramnthu==1|ganethu==1|dushthu==1|diwathu==1)
replace festhu=1 if mp==1&(holithu==1|ramnthu==1|janathu==1|dushthu==1|diwathu==1)
replace festhu=1 if or==1&(holithu==1|ashtthu==1|navathu==1|dushthu==1|diwathu==1)
replace festhu=1 if pu==1&(holithu==1|ramnthu==1|janathu==1|dushthu==1|diwathu==1)
replace festhu=1 if ra==1&(holithu==1|ramnthu==1|janathu==1|dushthu==1|diwathu==1)
replace festhu=1 if tn==1&(janathu==1|ganethu==1|navathu==1|dushthu==1|diwathu==1)
replace festhu=1 if up==1&(navathu==1|ramnthu==1|janathu==1|dushthu==1|diwathu==1)
replace festhu=1 if wb==1&(holithu==1|ashtthu==1|navathu==1|dushthu==1|diwathu==1)

capture drop fesfri
gen fesfri=0
replace fesfri=1 if ap==1&(ramnfri==1|ashtfri==1|navafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if as==1&(janafri==1|ashtfri==1|navafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if bh==1&(holifri==1|ramnfri==1|navafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if gu==1&(holifri==1|ramnfri==1|navafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if ha==1&(holifri==1|shivfri==1|janafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if jk==1&(shivfri==1|janafri==1|ramnfri==1|dushfri==1|diwafri==1)
replace fesfri=1 if ka==1&(shivfri==1|ganefri==1|navafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if ke==1&(shivfri==1|janafri==1|navafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if mh==1&(navafri==1|ramnfri==1|ganefri==1|dushfri==1|diwafri==1)
replace fesfri=1 if mp==1&(holifri==1|ramnfri==1|janafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if or==1&(holifri==1|ashtfri==1|navafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if pu==1&(holifri==1|ramnfri==1|janafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if ra==1&(holifri==1|ramnfri==1|janafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if tn==1&(janafri==1|ganefri==1|navafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if up==1&(navafri==1|ramnfri==1|janafri==1|dushfri==1|diwafri==1)
replace fesfri=1 if wb==1&(holifri==1|ashtfri==1|navafri==1|dushfri==1|diwafri==1)

capture drop fessat
gen fessat=0
replace fessat=1 if ap==1&(ramnsat==1|ashtsat==1|navasat==1|dushsat==1|diwasat==1)
replace fessat=1 if as==1&(janasat==1|ashtsat==1|navasat==1|dushsat==1|diwasat==1)
replace fessat=1 if bh==1&(holisat==1|ramnsat==1|navasat==1|dushsat==1|diwasat==1)
replace fessat=1 if gu==1&(holisat==1|ramnsat==1|navasat==1|dushsat==1|diwasat==1)
replace fessat=1 if ha==1&(holisat==1|shivsat==1|janasat==1|dushsat==1|diwasat==1)
replace fessat=1 if jk==1&(shivsat==1|janasat==1|ramnsat==1|dushsat==1|diwasat==1)
replace fessat=1 if ka==1&(shivsat==1|ganesat==1|navasat==1|dushsat==1|diwasat==1)
replace fessat=1 if ke==1&(shivsat==1|janasat==1|navasat==1|dushsat==1|diwasat==1)
replace fessat=1 if mh==1&(navasat==1|ramnsat==1|ganesat==1|dushsat==1|diwasat==1)
replace fessat=1 if mp==1&(holisat==1|ramnsat==1|janasat==1|dushsat==1|diwasat==1)
replace fessat=1 if or==1&(holisat==1|ashtsat==1|navasat==1|dushsat==1|diwasat==1)
replace fessat=1 if pu==1&(holisat==1|ramnsat==1|janasat==1|dushsat==1|diwasat==1)
replace fessat=1 if ra==1&(holisat==1|ramnsat==1|janasat==1|dushsat==1|diwasat==1)
replace fessat=1 if tn==1&(janasat==1|ganesat==1|navasat==1|dushsat==1|diwasat==1)
replace fessat=1 if up==1&(navasat==1|ramnsat==1|janasat==1|dushsat==1|diwasat==1)
replace fessat=1 if wb==1&(holisat==1|ashtsat==1|navasat==1|dushsat==1|diwasat==1)

xtset dist year

xtreg L.riot L.fessun L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)
test(L.fessun)
xtreg L.riot L.fesmon L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)
test(L.fesmon)
xtreg L.riot L.festue L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)
test(L.festue)
xtreg L.riot L.feswed L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)
test(L.feswed)
xtreg L.riot L.festhu L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)
test(L.festhu)
xtreg L.riot L.fesfri L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)
test(L.fesfri)
xtreg L.riot L.fessat L.bjprule muslim urb lit ele tap time tsq if ebjpvs!=., fe cl(dist)
test(L.fessat)
