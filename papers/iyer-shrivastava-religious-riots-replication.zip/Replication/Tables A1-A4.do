cd "D:\Dropbox\Religious riots and electoral politics in India\Replication\"
use "dataset_robustness.dta", clear

*Table A1
xtreg ebjpvs L.riot L.bjprule time tsq if year>1980, fe cl(dist)
xtreg ebjpvs L.riot L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)
xtivreg2 ebjpvs (L.riot= L.fes)  L.bjprule time tsq if year>1980, fe cl(dist)
xtivreg2 ebjpvs (L.riot= L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

*Table A2
xtreg eincvs L.riotnear200 L.incrule muslim urb lit ele tap time tsq, fe cl(dist)
xtivreg2 eincvs (L.riotnear200=L.fes) L.incrule muslim urb lit ele tap time tsq, fe cl(dist)

*Table A3

capture drop riotmus
capture drop fesmus
gen riotmus=L.riotnear200*muslim
gen fesmus=L.fes*muslim

xtivreg2 ebjpvs (L.riotnear200 riotmus= L.fes fesmus)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

capture drop riotlit
capture drop feslit
gen riotlit=L.riotnear200*lit
gen feslit=L.fes*lit

xtivreg2 ebjpvs (L.riotnear200 riotlit= feslit L.fes)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

capture drop rioturb
capture drop fesurb
gen rioturb=L.riotnear200*urb
gen fesurb=L.fes*urb

xtivreg2 ebjpvs (L.riotnear200 rioturb= L.fes fesurb)  L.bjprule muslim urb lit ele tap time tsq, fe cl(dist)

*Table A4
xtivreg2 ebjpvs (L.riotnear200= L.fes)  L.bjprule muslim urb lit ele tap time tsq if close3==1, fe cl(dist)
xtivreg2 ebjpvs (L.riotnear200= L.fes)  L.bjprule muslim urb lit ele tap time tsq if close2==1, fe cl(dist)
